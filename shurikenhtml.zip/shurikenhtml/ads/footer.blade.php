{{<!-- Histats.com  START (html only)-->
<a href="/" alt="page hit counter" target="_blank" >
<embed src="//s10.histats.com/107.swf"  flashvars="jver=1&acsid=4417474&domi=4"  quality="high"  width="170" height="20" name="107.swf"  align="middle" type="application/x-shockwave-flash" pluginspage="//www.macromedia.com/go/getflashplayer" wmode="transparent" /></a>
<img  src="//sstatic1.histats.com/0.gif?4417474&101" alt="best counter" border="0">
<!-- Histats.com  END  -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170029578-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170029578-1');
</script>



}}