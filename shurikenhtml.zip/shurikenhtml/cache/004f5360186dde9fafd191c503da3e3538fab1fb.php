<?php
	shuffle($sentences);
?>

<?php if(!empty($sentences)): ?>
	<p><?php echo e(@array_pop($sentences)); ?> <?php echo e(@array_pop($sentences)); ?></p>
<?php endif; ?>

<?php $__currentLoopData = collect($images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
	<p>
		<a href="<?php echo e($image['url']); ?>">
		<img class="img-fluid" src="<?php echo e($image['url']); ?>" width="100%" onerror="this.onerror=null;this.src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQh_l3eQ5xwiPy07kGEXjmjgmBKBRB7H2mRxCGhv1tFWg5c_mWT';"></a>
	<?php echo e($image['title']); ?>

	</p>

	<?php if($loop->first): ?>
		
		<h3><?php echo e(@array_pop($sentences)); ?></h3>
		<!--more--> 
		<img src="<?php echo e(collect($images)->random()['url']); ?>" width="100%" align="left" style="margin-right: 8px;margin-bottom: 8px;"> <?php $__currentLoopData = collect($sentences)->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunked_sentences): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<p>
				<?php if($loop->first): ?> <strong><?php echo e(ucfirst($keyword)); ?></strong>. <?php endif; ?> <?php $__currentLoopData = $chunked_sentences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunked_sentence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($chunked_sentence); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</p>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
	<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php /**PATH D:\laragon\www\shuriken1\views/export/post.blade.php ENDPATH**/ ?>