<?php
$default_author = 'Admin';
$site_url = 'http://example.com/';
$category = isset($argv[2]) ? $argv[2] : 'Uncategorized';
$backdate = isset($argv[1]) ? $argv[1] : date('Y-m-d');
?>
<?php echo '<' . '?' . 'xml version="1.0" encoding="UTF-8"'; ?>

<rss version="2.0"
	xmlns:excerpt="http://wordpress.org/export/1.0/excerpt/"
	xmlns:content="http://purl.org/rss/1.0/modules/content/"
	xmlns:wfw="http://wellformedweb.org/CommentAPI/"
	xmlns:dc="http://purl.org/dc/elements/1.1/"
	xmlns:wp="http://wordpress.org/export/1.0/"
>

<channel>
	<title>My Site</title>
	<link>http://example.com/</link>
	<description></description>
	<pubDate>Thu, 28 May 2009 16:06:40 +0000</pubDate>
	<wp:author><wp:author_id>1</wp:author_id><wp:author_login><![CDATA[admin]]></wp:author_login><wp:author_email><![CDATA[buchin@dropsugar.com]]></wp:author_email><wp:author_display_name><![CDATA[admin]]></wp:author_display_name><wp:author_first_name><![CDATA[]]></wp:author_first_name><wp:author_last_name><![CDATA[]]></wp:author_last_name></wp:author>
	
	<generator>http://wordpress.org/?v=2.7.1</generator>
	<language>en</language>
	<wp:wxr_version>1.0</wp:wxr_version>
	<wp:base_site_url>http://example.com/</wp:base_site_url>
	<wp:base_blog_url>http://example.com/</wp:base_blog_url>

	<?php $__currentLoopData = $keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_id => $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php
			$data = get_data(str_slug($keyword));
			$data['keyword'] = $keyword;
			$post_title = $keyword;
			$slug = str_slug( $post_title );
			$unixtime = rand(strtotime($backdate), time());
			$pubdate = date( 'D, d M Y H:i:s', $unixtime )." +0000";
			$post_date = date( 'Y-m-d H:i:s', $unixtime );
			$month = date('m', $unixtime);
			$day = date('d', $unixtime);
			$year = date('Y', $unixtime);

			$post_content = view('export.post', $data, false);
		?>
		<item>
			<title><![CDATA[<?php echo e(ucwords($keyword)); ?>]]></title>
			
			<link><?php echo e($site_url); ?><?php echo e($slug); ?>/</link>
			<pubDate><?php echo e($pubdate); ?></pubDate>

			<dc:creator><![CDATA[<?php echo e($default_author); ?>]]></dc:creator>
			<wp:postmeta>
				<wp:meta_key>_byline</wp:meta_key>
				<wp:meta_value><?php echo e($default_author); ?></wp:meta_value>
			</wp:postmeta>

			<?php
			$category = trim( $category );
			$cat_slug = str_slug( $category );
			?>

			<category><![CDATA[<?php echo e($category); ?>]]></category>
			<category domain="category" nicename="<?php echo e($cat_slug); ?>"><![CDATA[<?php echo e($category); ?>]]></category>
			
			<?php
				$tags = $data['related'];
			?>

			<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if( !empty( $tag )): ?>
					<?php
					$tag_slug = str_slug( $tag );
					?>

					<category domain="tag" nicename="<?php echo e($tag_slug); ?>"><![CDATA[<?php echo e($tag); ?>]]></category>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		
			<guid isPermaLink="false"><?php echo e($site_url); ?>?p=<?php echo e($post_id); ?></guid>
			<description></description>
			<content:encoded><![CDATA[<?php echo $post_content; ?>]]></content:encoded>
			<excerpt:encoded><![CDATA[]]></excerpt:encoded>
			<wp:post_id><?php echo e($post_id); ?></wp:post_id>
			<wp:post_date><?php echo e($post_date); ?></wp:post_date>
			<wp:post_date_gmt><?php echo e($post_date); ?></wp:post_date_gmt>
			<wp:comment_status>open</wp:comment_status>
			<wp:ping_status>closed</wp:ping_status>
			<wp:post_name><?php echo e($slug); ?></wp:post_name>

			<wp:status>publish</wp:status>
			<wp:post_parent>0</wp:post_parent>
			<wp:menu_order>0</wp:menu_order>
			<wp:post_type>post</wp:post_type>
			<wp:post_password></wp:post_password>
			
			<wp:postmeta>
				<wp:meta_key>_old_id</wp:meta_key>
				<wp:meta_value><?php echo e($post_id); ?></wp:meta_value>
			</wp:postmeta>


		</item>
		
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</channel>
</rss>
